//
//  China.h
//  SQLiteLX
//
//  Created by xwc on 16/2/23.
//  Copyright (c) 2016年 cyx. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface China : NSObject
@property (nonatomic,copy)NSString *name;
@property (nonatomic,copy)NSString *ID;
//@property (nonatomic,copy)NSString *proName;
//@property (nonatomic,copy)NSString *proID;
//@property (nonatomic,copy)NSString *cityName;
//@property (nonatomic,copy)NSString *cityID;
//@property (nonatomic,copy)NSString *zoneName;
@end
