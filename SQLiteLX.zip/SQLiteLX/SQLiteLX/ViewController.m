//
//  ViewController.m
//  SQLiteLX
//
//  Created by xwc on 16/2/19.
//  Copyright (c) 2016年 cyx. All rights reserved.
//

#import "ViewController.h"
#import "FMDatabase.h"
#import "FMDatabaseAdditions.h"
#import "China.h"
@interface ViewController ()<UITableViewDelegate,UITableViewDataSource>
{
    UITableView *_tableView;
    FMDatabase *_fmdb;
    NSMutableArray *_provinceArray;
    NSMutableArray *_cityArray;
    NSMutableArray *_zoneArray;
    NSMutableArray *_currentDataArray;
    NSInteger currentIndex;
    NSMutableDictionary *selectDic;
    int progress ;
}
@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    _provinceArray =[NSMutableArray array];
    _cityArray = [NSMutableArray array];
    _zoneArray = [NSMutableArray array];
    _currentDataArray = [NSMutableArray array];
    progress = 1;
    selectDic = [NSMutableDictionary dictionary];
    
    _tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 20, self.view.frame.size.width, self.view.frame.size.height-20) style:UITableViewStylePlain];
    _tableView.dataSource = self;
    _tableView.delegate = self;
//    _tableView.rowHeight = 
    [self.view addSubview:_tableView];
    
    NSString *filePath = [[NSBundle mainBundle] pathForResource:@"china_province_city_zone" ofType:@"sqlite"];
    _fmdb = [FMDatabase databaseWithPath:filePath];
    
    [self getData];
}
-(void)getData
{
//    [_currentDataArray removeAllObjects];
    
    //判断数据库能否打开
    if (![_fmdb open])
    {
        [_fmdb close];
        return;
    }
    //提高执行效率
    [_fmdb setShouldCacheStatements:YES];
    
    if (_provinceArray.count ==0)
    {
        NSLog(@"province");
        FMResultSet *result = [_fmdb executeQuery:@"SELECT * FROM T_Province"];
        while ([result next])
        {
            China *province = [China new];
            province.name = [result stringForColumn:@"ProName"];
            province.ID = [result stringForColumn:@"ProSort"];
            [_provinceArray addObject:province];
        }
        _currentDataArray = _provinceArray;
    }
    else if (_cityArray.count==0)
    {
        NSLog(@"city");
        China *province = [_provinceArray objectAtIndex:currentIndex];
        FMResultSet *result = [_fmdb executeQuery:@"SELECT * FROM T_City where ProID = ?",province.ID];
        while ([result next])
        {
            China *city = [China new];
            city.name = [result stringForColumn:@"CityName"];
            city.ID = [result stringForColumn:@"CitySort"];
            [_cityArray addObject:city];
        }
        _currentDataArray = _cityArray;
    }
    else if (_zoneArray.count==0)
    {
        NSLog(@"zone");
        China *city = [_provinceArray objectAtIndex:currentIndex];
        FMResultSet *result = [_fmdb executeQuery:@"SELECT * FROM T_Zone where CityID = ?",city.ID];
        while ([result next])
        {
            China *zone = [China new];
            zone.name = [result stringForColumn:@"ZoneName"];
            zone.ID = [NSString stringWithFormat:@"%d",[result intForColumn:@"ZoneID"]];
            [_zoneArray addObject:zone];
        }
        _currentDataArray = _zoneArray;
    }
    else
    {
        return;
    }
    [_tableView reloadData];
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return _currentDataArray.count;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *cellID = @"cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellID];
    if (!cell)
    {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellID];
    }
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    China *china = [China new];
    china = [_currentDataArray objectAtIndex:indexPath.row];
    cell.textLabel.text = china.name;
    return cell;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSLog(@"province==%lu",(unsigned long)_provinceArray.count);
    currentIndex = indexPath.row;
    
    China *china = [China new];
    china = [_currentDataArray objectAtIndex:indexPath.row];
    
    if (progress == 1){
        
        [selectDic setObject:china.name forKey:@"province"];
    }
    else if (progress == 2){
        
        [selectDic setObject:china.name forKey:@"city"];
    }
    else if (progress == 3){
        
        [selectDic setObject:china.name forKey:@"zone"];
    }
    NSLog(@"progress ---%d----dic---%@",progress,selectDic);
    [self getData];
    progress ++;
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
